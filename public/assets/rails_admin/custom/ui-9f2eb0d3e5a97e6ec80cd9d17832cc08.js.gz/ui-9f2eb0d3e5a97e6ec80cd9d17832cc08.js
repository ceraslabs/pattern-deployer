/*
  Meant to be overriden in user's app/assets/javascripts/rails_admin/custom directory. no content here

  Available resources:

  http://twitter.github.com/bootstrap/javascript.html
  https://github.com/twitter/bootstrap/tree/master/js
  http://jquery.com/
  http://jqueryui.com/ (parts of it)

  rename to ui.js.coffee if needed.
*/
;